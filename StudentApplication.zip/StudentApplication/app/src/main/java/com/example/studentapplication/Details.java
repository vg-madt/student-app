package com.example.studentapplication;

public class Details {
    private String name;
    private int fees;
    private int hours;

    public Details(String name, int fees, int hours) {
        this.name = name;
        this.fees = fees;
        this.hours = hours;
    }

    public String getName() {
        return name;
    }

    public int getFees() {
        return fees;
    }

    public int getHours() {
        return hours;
    }




}
