package com.example.studentapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity implements View.OnClickListener{
    EditText usr, pwd;
    Button login;
    static EditText name;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);
        name = findViewById(R.id.nameTxt);
        usr = findViewById(R.id.userName);
        pwd = findViewById(R.id.password);

        login = findViewById(R.id.loginButton);
        login.setOnClickListener(this);
    }
    @Override
    public void onClick(View v) {
    if(usr.getText().toString().equalsIgnoreCase((""))||name.getText().toString().equalsIgnoreCase("")
            || pwd.getText().toString().equals("")){
        Toast.makeText(getApplicationContext(), "Please enter all values", Toast.LENGTH_LONG).show();
    }
            else if(usr.getText().toString().equalsIgnoreCase("student1") && pwd.getText().toString().equals("123456"))
            {
                Intent intent = new Intent(this,MainActivity.class);
                startActivity(intent);
            }
            else {
                Toast.makeText(getApplicationContext(), "Invalid username or password", Toast.LENGTH_LONG).show();
            }
    }
}
