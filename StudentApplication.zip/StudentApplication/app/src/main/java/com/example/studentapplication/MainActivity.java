package com.example.studentapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener, View.OnClickListener {

    TextView wel,fee,hrs,totFees,totHours;
    RadioButton graduate,ungraduate;
    Spinner sp;
    Button add;
    CheckBox accomodation, medicalInsurance;
    String [] courses ={"Java","Swift","IOS","Android","Database"};
    ArrayList<Details> allDetails = new ArrayList<Details>();
    int totalhours = 0;
    int totalfees =0;

    //filling details
    public void fillCourseDetails(){
        allDetails.add(new Details("Java",1300,6));
        allDetails.add(new Details("Swift",1500,5));
        allDetails.add(new Details("IOS",1350,5));
        allDetails.add(new Details("Android",1400,7));
        allDetails.add(new Details("Database",1000,4));
    }


    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        wel =findViewById(R.id.welcome);
        wel.setText("Welcome "+ LoginActivity.name.getText().toString());
        fee=findViewById(R.id.fees);
        hrs=findViewById(R.id.hours);
        totFees=findViewById(R.id.totalHours);
        totFees=findViewById(R.id.totalFees);
        add=findViewById(R.id.addBtn);
        accomodation=findViewById(R.id.acc);
        medicalInsurance=findViewById(R.id.medIns);
        graduate=findViewById(R.id.grad);
        ungraduate=findViewById(R.id.ungrad);
        add.setOnClickListener(this);
        sp=findViewById(R.id.spinner);
        fillCourseDetails();
        
//spinner
        ArrayAdapter a = new ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,courses);
        a.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);
        sp.setAdapter(a);
        sp.setOnItemSelectedListener(this);

        // to add fees for accomodation and medical insurance
        accomodation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(accomodation.isChecked()) {
                    totalfees = totalfees + 1000;
                }
            }
        });

        medicalInsurance.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(medicalInsurance.isChecked()){
                    totalfees = totalfees + 700;
                }
            }
        }));


    }


//spinner total hours and fees addition
    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        String course = courses[position];
        for(int j=0;j<allDetails.size();j++) {
            if (course.equals(allDetails.get(j).getName())){
                fee.setText(allDetails.get(j).getFees());
                hrs.setText(allDetails.get(j).getHours());
                totalhours = totalhours + allDetails.get(j).getHours();
                totalfees = totalfees + allDetails.get(j).getFees();
            }

        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    //onclick listener of add button
    @Override
    public void onClick(View v) {
        {
            if(graduate.isSelected()){
                if(!(totalhours == 21)){
                    Toast.makeText(getApplicationContext(), "You cannot add this course", Toast.LENGTH_LONG).show();
                }
            }
            else if(ungraduate.isSelected()){
                if(!(totalhours == 19)){
                    Toast.makeText(getApplicationContext(), "You cannot add this course", Toast.LENGTH_LONG).show();
                }
            }

            //displays the total fees and total hours after addition
            totFees.setText(totalfees);
            totHours.setText(totalhours);
        }
    }
}
